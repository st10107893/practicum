
---question one
----------------------------------------------------------------------------------
---create instructor table
 CREATE TABLE INSTRUCTOR (
    ins_ID INT PRIMARY KEY,
    ins_fname VARCHAR2(25),
    ins_sname VARCHAR2(25),
    cust_contact VARCHAR2(10),
    ins_level INT
 );
 
   
 
 INSERT INTO INSTRUCTOR VALUES(101, 'James', 'Willis', '0843569851', 7);
 INSERT INTO INSTRUCTOR VALUES(102, 'Sam', 'Wait', '0763698521', 2);
 INSERT INTO INSTRUCTOR VALUES(103, 'Sally', 'Gumede', '0786598521', 8);
 INSERT INTO INSTRUCTOR VALUES(104, 'Bob', 'Du Pleez', '0796369857', 3);
 INSERT INTO INSTRUCTOR VALUES(105, 'Simon', 'Jones', '0826598741', 9);
 
 SELECT * FROM INSTRUCTOR;
 
--create customer table
 CREATE TABLE CUSTOMER24 (
    cust_id VARCHAR2(10) PRIMARY KEY,
    cust_fname VARCHAR2(25),
    cust_sname VARCHAR2(25),
    cust_address  VARCHAR2(100),
    cust_contact VARCHAR2(10)
 );
 
 
 
 INSERT INTO CUSTOMER24 VALUES ('C115', 'Heinrich', 'Willis', '3 Main Road', '0821253659');
 INSERT INTO CUSTOMER24 VALUES ('C116', 'David', 'Watson', '13 Cape Road', '0769658547');
 INSERT INTO CUSTOMER24 VALUES ('C117', 'Waldo', 'Smith', '3 Mountain Road', '0863256574');
 INSERT INTO CUSTOMER24 VALUES ('C118', 'Alex', 'Hanson', '8 Circle Road', '0762356587');
 INSERT INTO CUSTOMER24 VALUES ('C119', 'Kuhle', 'Bitterhout', '15 Main Road', '0821235258');
 INSERT INTO CUSTOMER24 VALUES ('C120', 'Thando', 'Zolani', '88 Summer Road', '0847541254');
 INSERT INTO CUSTOMER24 VALUES ('C121', 'Philip', 'Jackson', '3 Long Road', '0745556658');
 INSERT INTO CUSTOMER24 VALUES ('C122', 'Sarah', 'Jones', '7 Sea Road', '0814745745');
 INSERT INTO CUSTOMER24 VALUES ('C123', 'Catherine', 'Howard', '31 Lake Side Road', '0822232521');
   
SELECT * FROM CUSTOMER24;

 ---create dive table
  CREATE TABLE DIVE (
    dive_id INT PRIMARY KEY,
    dive_name VARCHAR2(25),
    dive_duration VARCHAR2(25),
    dive_location  VARCHAR2(100),
    dive_exp_level INT,
    dive_cost INT
 );
 
  
 
 INSERT INTO DIVE VALUES ( 550, 'Shark Dive', '3 hours ', 'Shark point', 8, 500);
 INSERT INTO DIVE VALUES ( 551, 'Coral Dive', '1 hour', 'Break Point', 7, 300);
 INSERT INTO DIVE VALUES ( 552, 'Wave Crescent', '2 hours', 'Ship wreck ally', 3, 800);
 INSERT INTO DIVE VALUES ( 553, 'Underwater Exploration', '1 hour', 'Coral ally', 2, 250);
 INSERT INTO DIVE VALUES ( 554, 'Underwater Adventure', '3 hours', 'Sandy Beach', 3, 750);
 INSERT INTO DIVE VALUES ( 555, 'Deep Blue Ocean', '30 minutes ', 'Lazy Waves', 2, 120);
 INSERT INTO DIVE VALUES ( 556, 'Rough seas', '1 hour ', 'Pipe', 9, 700);
 INSERT INTO DIVE VALUES ( 557, 'White Water ', '2 hour ', 'Drifts', 5, 200);
 INSERT INTO DIVE VALUES ( 558, 'Current Adventure', '2 hour ', 'Rock Lands', 3, 150);
 
 SELECT * FROM DIVE;
----create dive event table
CREATE TABLE DIVE_EVENT (
dive_event_ID VARCHAR2(25) PRIMARY KEY,
DIVE_DATE DATE,
dive_participants INT,
ins_ID INT,
cust_id VARCHAR(25),
dive_id INT,
FOREIGN KEY (ins_ID) REFERENCES INSTRUCTOR(ins_ID),
FOREIGN KEY (cust_id) REFERENCES  CUSTOMER24(cust_id),
FOREIGN KEY (dive_id) REFERENCES DIVE(dive_id)
);

 

INSERT INTO DIVE_EVENT VALUES ('de_101', '15-JULY-2024', 5, 103, 'C115', 558);
INSERT INTO DIVE_EVENT VALUES ('de_102', '16-JULY-2024', 7, 102, 'C117', 555);
INSERT INTO DIVE_EVENT VALUES ('de_103', '18-JULY-2024', 8, 104, 'C118', 552);
INSERT INTO DIVE_EVENT VALUES ('de_104', '19-JULY-2024', 3, 101, 'C119', 551);
INSERT INTO DIVE_EVENT VALUES ('de_105', '21-JULY-2024', 5, 104, 'C121', 558);
INSERT INTO DIVE_EVENT VALUES ('de_106', '22-JULY-2024', 8, 105, 'C120', 556);
INSERT INTO DIVE_EVENT VALUES ('de_107', '25-JULY-2024',10, 105, 'C115', 554);
INSERT INTO DIVE_EVENT VALUES ('de_108', '27-JULY-2024', 5, 101, 'C122', 552);
INSERT INTO DIVE_EVENT VALUES ('de_109', '28-JULY-2024', 3, 102, 'C123', 553);

SELECT * FROM DIVE_EVENT;


--------------------------------------------------------------------------------
--QUESTION TWO
--------------------------------------------------------------------------------
--create user ANY TSHEPO and grant privilege Insert any table---
CREATE USER C##Tshepo IDENTIFIED BY tmphoabc2023;
GRANT CONNECT TO C##Tshepo;
GRANT CREATE SESSION TO C##Tshepo;
GRANT SELECT ANY TABLE TO C##Tshepo;

--create user ANY USER and grant privilege Insert any table---
CREATE USER C##Mya IDENTIFIED BY mrobertabc2023;
GRANT CONNECT TO C##Mya;
GRANT CREATE SESSION TO C##Mya;
GRANT INSERT ANY TABLE TO C##Mya;


--------------------------------------------------------------------------------
--QUESTION THREE
-------------------------------------------------------------------------------
SELECT (I.ins_fname || ', ' || I.ins_sname) AS instructor, (C.cust_fname || ', ' || C.cust_sname )AS CUSTOMER, 
 dive_location, dive_participants 
FROM  INSTRUCTOR I,CUSTOMER24 C, DIVE D, DIVE_EVENT DE
WHERE I.ins_ID = DE.ins_ID
and C.cust_id = DE.cust_id
and D.dive_id = DE.dive_id
AND dive_participants < 10 AND dive_participants >= 8;
 
 
 
 
--------------------------------------------------------------------------------
--QUESTION FOUR
-------------------------------------------------------------------------------


SET SERVEROUTPUT ON
DECLARE
 d_name DIVE.dive_name%TYPE;
 D_DATE DIVE_EVENT.DIVE_DATE%TYPE;
 d_participants DIVE_EVENT.dive_participants%TYPE;
 
 cursor infor is
 SELECT DIVE_NAME , DIVE_DATE, dive_participants
 FROM DIVE D, DIVE_EVENT DE
 WHERE D.dive_id = DE. dive_id
 AND dive_participants >= 10;
 
 BEGIN
  FOR rec IN infor
  LOOP 
  d_name := rec.dive_name;
  d_date := rec.DIVE_DATE;
  d_participants := rec.dive_participants;
  
  DBMS_OUTPUT.PUT_LINE('DIVE NAME: ' || d_name || chr(10)||
  'DIVE DATE: ' || d_date || chr(10)||
  'PARTICIPANTS: ' || d_participants); 
  DBMS_OUTPUT.PUT_LINE('-----------------------------------------');
  
  END LOOP;
  END;
  /
  
  
  
  --------------------------------------------------------------------------------
--QUESTION FIVE
-------------------------------------------------------------------------------
SET SERVEROUTPUT ON
DECLARE

cf_name CUSTOMER24.cust_fname%TYPE;
d_name DIVE.dive_name%TYPE;
d_participants DIVE_EVENT.dive_participants%TYPE;
d_cost DIVE.dive_cost%TYPE;
PART1 INT := 1;
PART2 INT := 2;
PART3 INT := 3;

cursor infor is
 SELECT (C.cust_fname || ', ' || C.cust_sname )AS CUSTOMER , d.dive_name, de.dive_participants
 FROM CUSTOMER24 C, DIVE D, DIVE_EVENT DE
 WHERE D.dive_id = DE.dive_id
 and c.cust_id= DE.cust_id
 and dive_cost > 500;
 
BEGIN
FOR REC IN INFOR
LOOP 
 cf_name := REC.CUSTOMER;
d_name := REC.dive_name;
d_participants := REC.dive_participants;
d_cost := REC.dive_cost;


 DBMS_OUTPUT.PUT_LINE(
  'CUSTOMER: ' || cf_name || chr(10) ||
  'DIVE NAME: ' || d_name || chr(10)||
  'PARTICIPANTS: ' || d_participants );
 
 if  d_participants <= 4 then

  DBMS_OUTPUT.PUT_LINE('STATUS:' || PART1 || ' INSTRUCTORS REQUIRED.' ); 
  DBMS_OUTPUT.PUT_LINE('-----------------------------------------');
ELSIF d_participants >4 then
 DBMS_OUTPUT.PUT_LINE('STATUS:' || PART2 || ' INSTRUCTORS REQUIRED.' ); 
  DBMS_OUTPUT.PUT_LINE('-----------------------------------------');
  
  ELSIF d_participants >= 8 then
  DBMS_OUTPUT.PUT_LINE('STATUS:' || PART2 || ' INSTRUCTORS REQUIRED.' ); 
  DBMS_OUTPUT.PUT_LINE('-----------------------------------------');
  
 END IF;
 END LOOP;
 END;
 /
 
 
 --------------------------------------------------------------------------------
--QUESTION SIX
-------------------------------------------------------------------------------
    CREATE VIEW Vw_Dive_Event AS
SELECT i.ins_ID, c.cust_id, cust_address,dive_duration  
FROM INSTRUCTOR I, CUSTOMER24 C,  DIVE D, DIVE_EVENT DE
WHERE I.ins_ID = DE.ins_ID
and C.cust_id = DE.cust_id
and D.dive_id = DE.dive_id
 AND DIVE_DATE  < '17-JULY-2024'; 
 
 SELECT * from VIEW VW_DIVE_EVENT;
 
 
 
 --- question seven ---
 CREATE TRIGGER nEW_DIVE_EVENT 
 BEFORE INSERT ON DIVE_EVENT
 BEGIN
 RAISE_APPLICATION_ERROR (dive_participants < 0 OR  dive_participantS >20 ); 
 END;
/
 
 INSERT INTO DIVE_EVENT VALUES ('de_101', '15-JULY-2024', 26, 103, 'C115', 558);
------
 QUESTION 8
 create OR REPLACE precedure spcustomerdetails
 (ID IN CUSTOMER24.cust_id%TYPE,
 DATES IN DIVE_EVENT.DIVE_DATE%TYPE
 DETAILS OUT VARCHAR2)
 IS
 BEGIN 
 SELECT (C.cust_fname || ', ' || C.cust_sname )AS CUSTOMER , d.dive_name
 INTO DETAILS
  FROM CUSTOMER24 C, DIVE D, DIVE_EVENT DE
 WHERE D.dive_id = DE.dive_id
 and c.cust_id= DE.cust_id
 
  
 END;
 /
 
 
 SET SERVEROUTPUT ON;
 DECLARE
 
 DETAILS VARCHAR2(100);
 BEGIN
 
 spcustomerdetails('C115',DETAILS );
 DBMS_OUTPUT.PUT_line(details);
 EXCEPTION
 WHEN NO_DATA_FOUND THEN
 DBMS_OUTPUT.PUT_LINE('NO CUSTOMER IS FOUND!');
 END;
 /
 